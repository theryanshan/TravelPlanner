# TravelPlanner
This app is base on Google Maps, utilize Maps API functionality through ovlerlay, helping tourist visalize travel routes. 

Acceptance criteria for the Minimum Viable Product:
  * Route planning for ONE international major city
  * Route planning is targeted in short-term trip, varies from 1 to 15 days
  * User is able to search point of interests from database, and pin it on the map
  * User is able to plan a reasonalbe route according to order of visit
