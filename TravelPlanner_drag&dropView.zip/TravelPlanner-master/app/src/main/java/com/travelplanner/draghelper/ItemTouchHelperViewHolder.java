package com.travelplanner.draghelper;

public interface ItemTouchHelperViewHolder {
    void onItemSelected();
    void onItemClear();
}
